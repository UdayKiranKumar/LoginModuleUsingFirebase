package com.example.loginmodule;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by USER on 07-Aug-19.
 */

public class Student
{
    String name;
    int reg;


    public Student(String name, int reg) {
        this.name = name;
        this.reg = reg;
    }


}
